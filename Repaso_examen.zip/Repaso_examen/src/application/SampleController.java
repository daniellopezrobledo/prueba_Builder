package application;

import java.io.IOException;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Modality;
import javafx.stage.Stage;


public class SampleController {
	
	public TextArea mostrar ;
	 public TextField insertar;
	 public TextField contrasenia;
	
	public void mostrartext(){
		 
		
		mostrar.setText(insertar.getText());
	}
	
	public void mostrarpas() throws IOException {
		if (contrasenia.getText().equals("12345")) {
			FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("prueba.fxml"));
	        Parent root1 = (Parent) fxmlLoader.load();
	        Stage stage = new Stage();
	        stage.initModality(Modality.APPLICATION_MODAL);
	        stage.setTitle("JSON");
	        stage.setScene(new Scene(root1,600,400));  
	        stage.show();  
		}
	}
}
